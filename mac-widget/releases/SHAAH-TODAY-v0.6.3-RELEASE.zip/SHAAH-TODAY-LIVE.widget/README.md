# SHAAH Today LIVE v0.6.0 — Übersicht

## Sincronización equilibrada
- Übersicht lee caché local cada **30 segundos** (no consulta Supabase cada vez).
- Realtime despierta el agente cuando recibe eventos de `day_logs` (requiere publicación Realtime de esa tabla y `websocket-client`).
- El agente consulta Supabase como respaldo cada **90 segundos**, o vuelve a intentarlo tras una caída.
- Por tanto la pantalla suele reflejar eventos en menos de 30 s, pero no se garantiza latencia máxima bajo suspensión, red inestable o Realtime desactivado.

## Instalar
1. Copia `SHAAH-TODAY-LIVE.widget` a la carpeta de widgets de Übersicht.
2. Configura la clave **publicable** de Supabase REAL en `config.json` (nunca service_role). No subas tu copia de configuración ni tokens a GitHub.
3. Asegúrate de que Supabase Auth permite `http://127.0.0.1:8765/callback` como URL de retorno.
4. Ejecuta `python3 login_google.py` desde el directorio del widget para iniciar Google OAuth; se almacenan tokens en Keychain del Mac.
5. Ejecuta `install_agent.command` para instalar el agente de lectura y comprobación cada 72 horas de actualizaciones.
6. Puedes instalar `websocket-client` con `python3 -m pip install --user websocket-client` (si tu Python lo admite). Sin él funciona el polling.

## Actualizaciones
- El script `update_widget.py --check` comprueba una versión publicada sin instalarla.
- `update_widget.py --install` solo instala al ejecutarlo manualmente y si `allow_manual_install:true` y el manifiesto está disponible por HTTPS.
- Activar solo cuando se publique y verifique `https://trypartylol-max.github.io/shaah/mac-widget/manifest.json`.
- El sistema verifica SHA-256, limita el tamaño, comprueba rutas ZIP, conserva `config.json` y `update-config.json` y deja respaldo `.backup`.
- Un manifiesto y un hash en el mismo sitio no protegen frente a una cuenta GitHub comprometida: publicar con revisión de cambios y 2FA.
- **No habilitar todavía**: el repositorio y GitHub Pages aún deben publicarse.

## Seguridad y límites
El widget consulta `day_logs` con sesión de usuario. No debe contener claves secretas y no hace mutaciones de datos. El score/Next Move no han demostrado todavía paridad con el despliegue actual: valida contra SHAAH REAL antes de confiar en la cifra. La activación OAuth y Realtime deben probarse en tu Mac. Nada de esto cambia la base de datos de producción.


## Actualizaciones (v0.6.1)
- La búsqueda de versiones se ejecuta cada **72 horas (3 días)** si el agente está instalado y macOS lo permite.
- **Nunca descarga ni instala por defecto.** Solo consulta el manifiesto HTTPS y muestra una notificación de macOS si encuentra una versión nueva. El aviso se da una vez por versión.
- `python3 update_widget.py --check` comprueba manualmente sin descargar ni instalar.
- Las instalaciones manuales están desactivadas inicialmente (`allow_manual_install: false` en `update-config.json`). Para autorizar una instalación puntual, revisa la versión y la fuente, cambia localmente a `true` y ejecuta `python3 update_widget.py --install`. Vuelve a poner `false` después.
- Si el repositorio de distribución no está publicado, la comprobación fallará de forma segura, sin descargar nada.
- Las alertas pueden necesitar permisos de notificación de macOS; no son garantía de entrega si macOS bloquea `osascript`.

## v0.6.2 — correcciones de seguridad
- OAuth verifica `state` por solicitud y protege el retorno local contra respuestas ajenas.
- Renovación de refresh token con bloqueo entre agente y lecturas.
- El score/Next Move se muestran **como provisionales**, no homologados.
- El actualizador rechaza paquetes con configuración privada y preserva respaldos anteriores.
- No se descarga ni instala nada en las comprobaciones de 72 horas.

## Actualizaciones opcionales
Para activar comprobaciones cada 72 h, copia `update-config.example.json` a `update-config.json` y cambia `check_enabled` a true. Solo avisa: `allow_manual_install` permanece false. Reinstala el agente tras habilitarlas. No hay descarga ni instalación automática.

#!/usr/bin/env python3
"""Read-only SHAAH Today; never writes application data."""
import datetime,json,pathlib,subprocess,urllib.parse,urllib.request,urllib.error,zoneinfo,math,contextlib,fcntl
ROOT=pathlib.Path(__file__).resolve().parent
PROJECT='llpyxktcfubhmthqujpa'
BASE=f'https://{PROJECT}.supabase.co'
SERVICE='shaah-today-oauth-refresh'
def output(d):print(json.dumps(d,ensure_ascii=False,allow_nan=False))
def keychain():
 p=subprocess.run(['security','find-generic-password','-a',PROJECT,'-s',SERVICE,'-w'],capture_output=True,text=True)
 return p.stdout.strip() if p.returncode==0 else ''
def save_token(t):subprocess.run(['security','add-generic-password','-U','-a',PROJECT,'-s',SERVICE,'-w',t],capture_output=True,check=True)
def call(route,key,access=None,body=None):
 headers={'apikey':key,'Content-Type':'application/json'}
 if access:headers['Authorization']='Bearer '+access
 req=urllib.request.Request(BASE+route,data=json.dumps(body).encode() if body is not None else None,headers=headers,method='POST' if body is not None else 'GET')
 with urllib.request.urlopen(req,timeout=15) as r:return json.load(r)
@contextlib.contextmanager
def token_lock():
 lock=pathlib.Path.home()/'Library'/'Application Support'/'SHAAH-Today'/'refresh.lock'
 lock.parent.mkdir(parents=True,exist_ok=True)
 with lock.open('a') as handle:
  fcntl.flock(handle,fcntl.LOCK_EX)
  try:yield
  finally:fcntl.flock(handle,fcntl.LOCK_UN)

def authenticated_session(key):
 with token_lock():
  refresh=keychain()
  if not refresh:return None
  token=call('/auth/v1/token?grant_type=refresh_token',key,body={'refresh_token':refresh})
  access=token.get('access_token')
  if not access:raise ValueError('No se pudo renovar la sesión')
  newrefresh=token.get('refresh_token')
  if newrefresh and newrefresh!=refresh:save_token(newrefresh)
  user=call('/auth/v1/user',key,access)
  if not user.get('id'):raise ValueError('Usuario no validado')
  return access,user['id']

def safepts(v):
 try:
  n=math.floor(float(v)+.5)
  return max(0,min(999,n)) if math.isfinite(float(v)) else 0
 except (ValueError,TypeError,OverflowError):return 0
def frac(v):return 1 if v is True else v if isinstance(v,(int,float)) and not isinstance(v,bool) and 0<v<1 else 0
def grade(p):return 'S+' if p>=95 else 'S' if p>=85 else 'A' if p>=72 else 'B' if p>=45 else 'C' if p>=30 else 'D' if p>=15 else 'F'
def modepts(item,mode):return safepts(item.get('pVacation' if mode=='vacation' else 'pWork',item.get('p',0)))
def compute(cfg,day,date):
 if not isinstance(cfg,dict) or not isinstance(day,dict):return None
 H=cfg.get('h',{});order=cfg.get('order',[]);subs=cfg.get('subs',[]);timeline=cfg.get('log',[])
 mode=cfg.get('travel',{}).get('mode','work')
 if isinstance(timeline,list) and timeline:
  matching=sorted((e for e in timeline if isinstance(e,dict) and isinstance(e.get('from'),str) and e['from']<=date),key=lambda e:e['from'])
  if matching:
   era=matching[-1];H=era.get('h',H);order=era.get('order',order);subs=era.get('subs',subs);mode=era.get('mode',mode)
 if not isinstance(H,dict) or not isinstance(order,list):return None
 mode='vacation' if mode=='vacation' else 'work'
 if not isinstance(subs,list):subs=[]
 check=day.get('_checks') or {};social=day.get('_social') or {}
 if not isinstance(check,dict) or not isinstance(social,dict):return None
 comboid=next((id for id,i in H.items() if isinstance(i,dict) and i.get('combo')),None)
 cp=modepts(H.get(comboid),mode) if comboid else 18
 active=[]
 for x in subs:
  if not isinstance(x,dict) or x.get('on') is False:continue
  x=dict(x);n=max(1,len(subs))
  # SHAAH's ensureModePts initializes missing mode points from legacy p, then resolveSubs uses them.
  base=safepts(x.get('p',0))
  x.setdefault('pWork',base);x.setdefault('pVacation',base)
  active.append({'id':x.get('id'),'label':x.get('label',x.get('id','')),'pts':modepts(x,mode)})
 levels=[[],[],[]]
 for id in order:
  x=H.get(id)
  if not isinstance(x,dict) or x.get('on') is False or (mode=='vacation' and id=='work'):continue
  lv=x.get('lv')
  if lv not in (1,2,3):continue
  pts=sum(z['pts'] for z in active) if x.get('combo') and active else modepts(x,mode)
  levels[lv-1].append({'id':id,'label':x.get('l',id),'pts':pts,'combo':bool(x.get('combo'))})
 lpoints=[];lmax=[];remaining=[]
 ticked=sum(z['pts'] for z in active if social.get(z['id']))
 for entries in levels:
  earned=0;maxpts=0
  for x in entries:
   maxpts+=x['pts']
   if x['combo']:
    if check.get(x['id']):earned+=ticked if ticked>0 else x['pts']
   else:
    earned+=math.floor(x['pts']*frac(check.get(x['id']))+.5)
    if not check.get(x['id']) and x['pts']>0:remaining.append(x)
  lpoints.append(earned);lmax.append(maxpts)
 for x in active:
  if not social.get(x['id']) and x['pts']>0:remaining.append(x)
 total=sum(lpoints);max_total=sum(lmax)
 if max_total<=0:return None
 pct=round(total/max_total*100)
 current=grade(total/max_total*100)
 next_target=next((s for s in range(total+1,max_total+1) if grade(s/max_total*100)!=current),None)
 nextmove=None
 if next_target is not None:
  need=next_target-total
  eligible=sorted((x for x in remaining if x['pts']>=need),key=lambda x:x['pts'])
  candidates=eligible or sorted(remaining,key=lambda x:-x['pts'])
  if candidates:
   x=candidates[0]
   nextmove={'label':x['label'],'pts':x['pts'],'target':grade(next_target/max_total*100),'need':need,'reaches':bool(eligible)}
  else:nextmove={'label':'Sin acciones pendientes identificadas','target':grade(next_target/max_total*100),'need':need}
 return {'mode':mode.upper(),'score':total,'max':max_total,'percent':pct,'grade':current,'levels':[{'score':lpoints[i],'max':lmax[i],'percent':round(lpoints[i]/lmax[i]*100) if lmax[i] else None} for i in range(3)],'nextMove':nextmove,'completed':sum(v is True for v in check.values()),'recordedChecks':len(check)}
def main():
 base={'status':'Sin conexión','percent':None,'grade':None,'levels':[None]*3,'nextMove':None}
 try:
  cfg=json.loads((ROOT/'config.json').read_text());key=cfg['publishable_key']
  if not key.startswith(('sb_publishable_','eyJ')):raise ValueError('Clave publicable inválida')
  session=authenticated_session(key)
  if not session:return output({**base,'error':'Falta conectar Google. Ejecuta login_google.py una vez.'})
  access,uid=session
  qs=lambda s:urllib.parse.quote(str(s),safe='')
  settings=call('/rest/v1/day_logs?select=data&date=eq.settings&user_id=eq.'+qs(uid)+'&limit=1',key,access)
  conf=(settings[0].get('data') or {}).get('_cfg') if settings else None
  if not isinstance(conf,dict):return output({**base,'status':'Conectado','error':'Configuración SHAAH no disponible'})
  tz=conf.get('tz');today=datetime.datetime.now(zoneinfo.ZoneInfo(tz) if tz and tz!='device' else datetime.datetime.now().astimezone().tzinfo).date().isoformat()
  rows=call('/rest/v1/day_logs?select=data&date=eq.'+qs(today)+'&user_id=eq.'+qs(uid)+'&limit=1',key,access)
  daily=(rows[0].get('data') or {}) if rows else {}
  calculated=compute(conf,daily,today)
  result={**base,'status':'Conectado','date':today,'lastSync':datetime.datetime.now().strftime('%H:%M')}
  if calculated:result.update(calculated)
  else:result['message']='Score no disponible: revisar configuración/registro del día.'
  result['source']='Cálculo provisional no homologado con SHAAH desplegado'
  result['message']='Score y Next Move provisionales: requieren prueba de paridad con SHAAH REAL.'
  return output(result)
 except urllib.error.HTTPError as e:return output({**base,'error':f'Error HTTP {e.code}: revisa sesión, permisos y configuración.'})
 except Exception as e:return output({**base,'error':str(e)[:180]})
if __name__=='__main__':main()

#!/bin/bash
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
LABEL="com.shaah.today.live"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
mkdir -p "$HOME/Library/LaunchAgents" "$HOME/Library/Logs"
# Best effort: install optional Realtime client (fallback polling works without it).
python3 -c 'import websocket' 2>/dev/null || echo 'Realtime opcional no disponible. Para activarlo: python3 -m pip install --user websocket-client'
python3 - "$DIR" "$PLIST" <<'PY'
import pathlib,plistlib,sys
root,path=map(pathlib.Path,sys.argv[1:])
config={'Label':'com.shaah.today.live','ProgramArguments':['/usr/bin/env','python3',str(root/'live_agent.py')], 'RunAtLoad':True,'KeepAlive':True,'StandardOutPath':str(pathlib.Path.home()/'Library/Logs/shaah-today-live.log'),'StandardErrorPath':str(pathlib.Path.home()/'Library/Logs/shaah-today-live-error.log')}
path.write_bytes(plistlib.dumps(config))
PY
launchctl bootout "gui/$(id -u)" "$PLIST" 2>/dev/null || true
launchctl bootstrap "gui/$(id -u)" "$PLIST"
launchctl kickstart -k "gui/$(id -u)/$LABEL"
echo "Agente instalado. Si aún no has iniciado Google OAuth, ejecuta login_google.py y reinicia el agente."
# Update checks remain disabled unless user opts in by creating update-config.json.
if [ ! -f "$DIR/update-config.json" ]; then
  echo 'Actualizaciones desactivadas. Copia update-config.example.json a update-config.json y actívalas si quieres.'
  exit 0
fi
# Notification-only check every 72h. Never downloads or installs.
UPLIST="$HOME/Library/LaunchAgents/com.shaah.today.updater.plist"
python3 - "$DIR" "$UPLIST" <<'PY'
import pathlib,plistlib,sys
root,path=map(pathlib.Path,sys.argv[1:])
conf={'Label':'com.shaah.today.updater','ProgramArguments':['/usr/bin/env','python3',str(root/'update_widget.py')], 'StartInterval':259200,'StandardOutPath':str(pathlib.Path.home()/'Library/Logs/shaah-today-update.log'),'StandardErrorPath':str(pathlib.Path.home()/'Library/Logs/shaah-today-update-error.log')}
path.write_bytes(plistlib.dumps(conf))
PY
launchctl bootout "gui/$(id -u)" "$UPLIST" 2>/dev/null || true
launchctl bootstrap "gui/$(id -u)" "$UPLIST"

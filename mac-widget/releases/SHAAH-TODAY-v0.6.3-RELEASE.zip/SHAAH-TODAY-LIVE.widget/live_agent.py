#!/usr/bin/env python3
"""Read-only refresh agent. Realtime events trigger a new read; polling is fallback."""
import datetime, json, os, pathlib, subprocess, threading, time, urllib.parse
from fetch import PROJECT, BASE, authenticated_session
ROOT=pathlib.Path(__file__).resolve().parent
CACHE=pathlib.Path.home()/'.cache'/'shaah-today-live.json'
STOP=threading.Event()

def snapshot(reason):
    try:
        proc=subprocess.run(['/usr/bin/env','python3',str(ROOT/'fetch.py')],capture_output=True,text=True,timeout=35)
        data=json.loads(proc.stdout)
        if not isinstance(data,dict): raise ValueError('Invalid snapshot')
        data['transport']=reason
        data['agentAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        CACHE.parent.mkdir(parents=True,exist_ok=True)
        tmp=CACHE.with_suffix('.tmp')
        tmp.write_text(json.dumps(data,ensure_ascii=False))
        os.replace(tmp,CACHE)
        return True
    except Exception as exc:
        print('Snapshot error:',str(exc)[:200],flush=True)
        return False

def credentials():
    key=json.loads((ROOT/'config.json').read_text())['publishable_key']
    session=authenticated_session(key)
    if session is None:raise RuntimeError('Run Google login first')
    access,uid=session
    return key,access,uid

def realtime_once():
    # websocket-client is optional. Polling continues if it is not installed or the server rejects a channel.
    import websocket
    key,access,uid=credentials()
    wsurl=BASE.replace('https://','wss://')+'/realtime/v1/websocket?'+urllib.parse.urlencode({'apikey':key,'vsn':'1.0.0'})
    ws=websocket.create_connection(wsurl,timeout=10,header=['Authorization: Bearer '+access])
    try:
        join={'topic':'realtime:shaah-today-live','event':'phx_join','payload':{'config':{'postgres_changes':[{'event':'*','schema':'public','table':'day_logs','filter':'user_id=eq.'+uid}]},'access_token':access},'ref':'1'}
        ws.send(json.dumps(join))
        ws.settimeout(8)
        confirmed=False
        deadline=time.monotonic()+20
        last_poll=time.monotonic()
        last_heartbeat=0
        started=time.monotonic()
        while not STOP.is_set() and time.monotonic()-started<600:
            now=time.monotonic()
            if now-last_heartbeat>25:
                ws.send(json.dumps({'topic':'phoenix','event':'heartbeat','payload':{},'ref':str(int(now))}))
                last_heartbeat=now
            if now-last_poll>=90:
                snapshot('respaldo 90 s');last_poll=now
            try: msg=json.loads(ws.recv())
            except websocket.WebSocketTimeoutException:
                if not confirmed and time.monotonic()>deadline:raise RuntimeError('Realtime subscription not confirmed')
                continue
            event=msg.get('event')
            if event=='phx_reply' and msg.get('ref')=='1':
                if msg.get('payload',{}).get('status')!='ok': raise RuntimeError('Realtime channel rejected')
                confirmed=True
                print('Realtime connected',flush=True)
            if event=='postgres_changes' and confirmed:
                snapshot('Realtime');last_poll=time.monotonic()
            if event in ('phx_error','phx_close'):raise RuntimeError('Realtime connection closed')
    finally:ws.close()

def main():
    print('SHAAH Today agent running (read-only)',flush=True)
    snapshot('inicio')
    while not STOP.is_set():
        try: realtime_once()
        except Exception as exc:
            print('Realtime unavailable; polling backup:',str(exc)[:150],flush=True)
            STOP.wait(90)
            snapshot('respaldo 90 s')

if __name__=='__main__':main()

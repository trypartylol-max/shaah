#!/usr/bin/env python3
"""Localhost Google OAuth PKCE, no password input, refresh token kept in macOS Keychain."""
import base64,hashlib,http.server,json,secrets,subprocess,urllib.parse,urllib.request,webbrowser,pathlib
ROOT=pathlib.Path(__file__).resolve().parent
PROJECT='llpyxktcfubhmthqujpa'
BASE=f'https://{PROJECT}.supabase.co'
SERVICE='shaah-today-oauth-refresh'
PORT=8765
REDIRECT=f'http://127.0.0.1:{PORT}/callback'

def main():
 key=json.loads((ROOT/'config.json').read_text())['publishable_key']
 oauth_state=secrets.token_urlsafe(32)
 verifier=base64.urlsafe_b64encode(secrets.token_bytes(48)).decode().rstrip('=')
 challenge=base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('=')
 class Handler(http.server.BaseHTTPRequestHandler):
  code=None; failure=None
  def do_GET(self):
   u=urllib.parse.urlparse(self.path)
   q=urllib.parse.parse_qs(u.query)
   if u.path!='/callback':
    self.send_response(400);self.end_headers();self.wfile.write(b'Invalid callback');return
   if not secrets.compare_digest(q.get('state',[''])[0],oauth_state):
    self.__class__.failure='OAuth state inválido';self.send_response(400);self.end_headers();self.wfile.write(b'Invalid OAuth state');return
   self.__class__.code=q.get('code',[None])[0]
   self.__class__.failure=q.get('error_description',q.get('error',[None]))[0]
   self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.end_headers()
   self.wfile.write('<h2>SHAAH: Puedes cerrar esta ventana.</h2>'.encode())
  def log_message(self,*args):pass
 url=BASE+'/auth/v1/authorize?'+urllib.parse.urlencode({'provider':'google','redirect_to':REDIRECT,'code_challenge':challenge,'code_challenge_method':'s256','state':oauth_state})
 print('Se abrirá Google en tu navegador. Nunca introduzcas tu contraseña en Terminal.')
 print('Si aparece un error de redirección, añade esta URL EXACTA a Supabase > Authentication > URL Configuration > Redirect URLs:')
 print(REDIRECT)
 with http.server.HTTPServer(('127.0.0.1',PORT),Handler) as server:
  server.timeout=180
  webbrowser.open(url)
  server.handle_request()
 if Handler.failure:raise SystemExit('Google OAuth falló: '+Handler.failure)
 if not Handler.code:raise SystemExit('No se recibió autorización. Comprueba la URL de retorno autorizada.')
 payload=json.dumps({'auth_code':Handler.code,'code_verifier':verifier}).encode()
 req=urllib.request.Request(BASE+'/auth/v1/token?grant_type=pkce',data=payload,headers={'apikey':key,'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(req,timeout=20) as res:tokens=json.load(res)
 except Exception as exc:raise SystemExit('No se pudo canjear el código OAuth: '+str(exc))
 refresh=tokens.get('refresh_token')
 if not refresh:raise SystemExit('La sesión no devolvió refresh_token')
 subprocess.run(['security','add-generic-password','-U','-a',PROJECT,'-s',SERVICE,'-w',refresh],check=True)
 print('Sesión guardada en Keychain. Actualiza los widgets de Übersicht.')
if __name__=='__main__':main()

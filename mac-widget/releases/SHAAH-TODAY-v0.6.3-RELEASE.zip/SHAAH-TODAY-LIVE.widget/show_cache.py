#!/usr/bin/env python3
"""Fast cache reader for Übersicht; does not access Supabase."""
import datetime,json,pathlib
p=pathlib.Path.home()/'.cache'/'shaah-today-live.json'
try:
 d=json.loads(p.read_text())
 stamp=d.get('agentAt')
 age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(stamp)).total_seconds() if stamp else 999999
 if age>120:
  d['status']='Desactualizado';d['message']='Sin cambios recientes: comprueba el agente de sincronización.'
 d['ageSeconds']=max(0,int(age))
 print(json.dumps(d,ensure_ascii=False))
except Exception:
 print(json.dumps({'status':'Agente sin iniciar','message':'Ejecuta install_agent.command y completa Google OAuth.'}))

#!/usr/bin/env python3
"""Opt-in updater for SHAAH Today. HTTPS manifest, checked archive, rollback backup."""
import argparse, hashlib, io, json, os, pathlib, re, shutil, subprocess, sys, tempfile, urllib.parse, urllib.request, zipfile
ROOT = pathlib.Path(__file__).resolve().parent
VERSION_FILE = ROOT / 'VERSION'
MAX_ARCHIVE = 5_000_000
MAX_EXTRACTED = 15_000_000
STATE = pathlib.Path.home()/"Library"/"Application Support"/"SHAAH-Today"/"update-notification.json"

def version_of(raw):
    if not isinstance(raw, str) or not re.fullmatch(r'\d+\.\d+\.\d+', raw):
        raise ValueError('Versión semántica inválida')
    return tuple(map(int, raw.split('.')))

def fetch_bytes(url, maximum):
    with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent':'SHAAH-Today-Updater'}),timeout=20) as response:
        if urllib.parse.urlsplit(response.geturl()).scheme != 'https':
            raise ValueError('Redirección insegura')
        data = response.read(maximum+1)
        if len(data)>maximum: raise ValueError('Archivo demasiado grande')
        return data

def notify(version):
    """Best effort user notification, never launches an installer."""
    title='SHAAH Today: actualización disponible'
    message=f'Versión {version} disponible. Abre el widget para actualizar manualmente.'
    try:
        subprocess.run(['/usr/bin/osascript','-e','on run argv','-e','display notification (item 2 of argv) with title (item 1 of argv)','-e','end run',title,message], timeout=10, check=False, capture_output=True)
    except (OSError, subprocess.TimeoutExpired):
        pass

def notify_once(version):
    try:
        state=json.loads(STATE.read_text()) if STATE.exists() else {}
        if state.get('last_notified_version') == version:return
        notify(version)
        STATE.parent.mkdir(parents=True, exist_ok=True)
        STATE.write_text(json.dumps({'last_notified_version':version})+'\n')
    except (OSError, ValueError) as exc:
        print('No se pudo persistir aviso:',exc,file=sys.stderr)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--install',action='store_true',help='Instalar actualización únicamente tras ejecución manual explícita')
    parser.add_argument('--check',action='store_true',help='Solo comprobar (comportamiento por defecto)')
    args=parser.parse_args()
    config_file=ROOT/'update-config.json'
    if not config_file.exists():
        print('Actualizaciones desactivadas: configura update-config.json explícitamente.'); return
    conf=json.loads(config_file.read_text())
    if not conf.get('check_enabled', False):
        print('Comprobación de actualizaciones desactivada.'); return
    url=conf.get('manifest_url','')
    parts=urllib.parse.urlsplit(url)
    if parts.scheme!='https' or not parts.hostname or parts.username or parts.password:
        raise ValueError('Manifiesto debe usar HTTPS válido')
    manifest=json.loads(fetch_bytes(url,64_000))
    new_version=version_of(manifest['version'])
    current=version_of(VERSION_FILE.read_text().strip())
    if new_version<=current:
        print('Widget actualizado: '+VERSION_FILE.read_text().strip()); return
    archive_url=manifest['zip_url']; hash_expected=manifest['sha256']
    remote=urllib.parse.urlsplit(archive_url)
    if remote.scheme!='https' or remote.hostname!=parts.hostname or remote.port!=parts.port or remote.username or remote.password:
        raise ValueError('ZIP debe estar en el mismo origen HTTPS que el manifiesto')
    if not isinstance(hash_expected,str) or not re.fullmatch('[a-fA-F0-9]{64}',hash_expected):
        raise ValueError('SHA256 inválido')
    print('Nueva versión disponible: '+manifest['version'])
    if not args.install:
        notify_once(manifest['version'])
        return
    if not conf.get('allow_manual_install', False):
        print('Instalación desactivada. No se ha descargado nada.'); return
    blob=fetch_bytes(archive_url,MAX_ARCHIVE)
    if hashlib.sha256(blob).hexdigest()!=hash_expected.lower():
        raise ValueError('SHA256 no coincide: se bloquea instalación')
    with tempfile.TemporaryDirectory(dir=str(ROOT.parent)) as tmp:
        stage=pathlib.Path(tmp)/ROOT.name
        stage.mkdir()
        size=0; file_count=0
        with zipfile.ZipFile(io.BytesIO(blob)) as z:
            for info in z.infolist():
                path=pathlib.PurePosixPath(info.filename)
                if path.is_absolute() or '..' in path.parts or not path.parts or path.parts[0]!=ROOT.name:
                    raise ValueError('Ruta ZIP no permitida')
                mode=(info.external_attr >> 16) & 0o170000
                if mode not in (0,0o100000,0o040000):
                    raise ValueError('Tipo de archivo no permitido')
                if info.is_dir(): continue
                if len(path.parts)<2: raise ValueError('Archivo en raíz ZIP inesperado')
                size+=info.file_size;file_count+=1
                if size>MAX_EXTRACTED or file_count>100:raise ValueError('ZIP excede límites')
                target=stage.joinpath(*path.parts[1:]);target.parent.mkdir(parents=True,exist_ok=True)
                with z.open(info) as source, target.open('wb') as sink:
                    shutil.copyfileobj(source,sink)
                if target.suffix=='.command':target.chmod(0o700)
        needed=['index.jsx','fetch.py','update_widget.py','VERSION','login_google.py','live_agent.py','show_cache.py']
        if not all((stage/x).is_file() for x in needed):raise ValueError('Paquete incompleto')
        if version_of((stage/'VERSION').read_text().strip())!=new_version:raise ValueError('Versión del paquete no coincide')
        # Never accept embedded user config or hidden executable paths from the release.
        if any((stage/name).exists() for name in ('config.json','update-config.json')):
            raise ValueError('La versión remota contiene configuración privada')
        # Never allow a release to overwrite local auth settings.
        for private in ('config.json','update-config.json'):
            if (ROOT/private).exists():shutil.copy2(ROOT/private,stage/private)
        backup=ROOT.with_name(ROOT.name+'.backup')
        older=ROOT.with_name(ROOT.name+'.backup.previous')
        # Preserve the previous backup instead of deleting it before the new install is validated.
        if older.exists():raise ValueError('Existe respaldo previo; revisa antes de actualizar')
        if backup.exists():backup.rename(older)
        ROOT.rename(backup)
        try:
            shutil.copytree(stage,ROOT)
        except BaseException:
            if ROOT.exists():shutil.rmtree(ROOT)
            backup.rename(ROOT)
            raise
        print('Instalado '+manifest['version']+'; respaldo en '+str(backup))

if __name__=='__main__':
    try:main()
    except Exception as exc:
        print('No se actualizó: '+str(exc),file=sys.stderr)
        sys.exit(1)
